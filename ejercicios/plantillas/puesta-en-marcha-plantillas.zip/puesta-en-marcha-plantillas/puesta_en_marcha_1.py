def main():
    print("PUESTA EN MARCHA 1")
    print("¡Funciona!")


if __name__ == "__main__":
    main()
