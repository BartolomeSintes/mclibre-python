def main():
    print("PUESTA EN MARCHA 2)
    nombre = input "Escriba su nombre: ")
    print(f"¡Hola, {nombres}!")


if __name__ == "__main__":
    mein(
