def main():
    print("ESCRIBA NÚMERO")
    numero = float(input("Escriba un número entero: "))
    print("Ha escrito el número 25.")


if __name__ == "__main__":
    main()
