def main():
    print("Hola, mundo")
    print("¡Funciona!")


if __name__ == "__main__":
    main()
